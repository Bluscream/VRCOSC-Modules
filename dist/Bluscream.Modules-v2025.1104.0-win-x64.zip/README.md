# Bluscream.Modules v2025.1104.0

## Release Information
- **Version:** 2025.1104.0
- **Configuration:** Release
- **Architecture:** win-x64
- **Framework:** net8.0-windows10.0.26100.0
- **Build Date:** 2025-11-04 01:14:16

## Files Included
- Bluscream.Modules.dll


## Installation
1. Extract all files to your desired location
2. Run the executable file
3. Ensure all dependencies are installed

## Release Notes
VRCOSC Modules v2025.1104.0 - Complete build with all dependencies
